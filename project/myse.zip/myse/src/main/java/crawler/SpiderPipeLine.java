package crawler;

import entity.Message;
import entity.MessageManager;
import org.junit.Test;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;
import lucenetest.MyIkTest;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Auther: bai
 * @Date: 2018/11/29 15:33
 * @Description:
 */

public class SpiderPipeLine implements Pipeline {

//    private MyIkTest myIkTest = new MyIkTest();

    private static List<Map.Entry<String, Integer>> list ;

    private Message message;

    private MessageManager messageManager;

    public synchronized void process(ResultItems resultItems, Task task) {
        message = new Message();
        messageManager = new MessageManager();
        System.out.println("(myPipeline) get Page ：" + resultItems.getRequest().getUrl());
        String title = resultItems.get("title");
        String url = resultItems.get("url").toString();
        System.out.println("(myPipeline) title ：" + resultItems.get("title"));
        message.setTitle(title);
        message.setUrl(url);
        message.setText(resultItems.get("content").toString());
        message.setDate(new Date());
        try {
            messageManager.save(message);
        }catch (Exception ex) {
            try {
                throw new Exception("");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Test
    public void showInConsole(List<Map.Entry<String, Integer>> list) {
        for (int k = 0; k < list.size(); k++) {

            Map.Entry<String, Integer> it = list.get(k);

            String word = it.getKey().toString();

            System.out.print(word + "[" + it.getValue() + "]  " );

        }
    }
}
