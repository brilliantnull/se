package crawler;

import entity.MessageManager;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

import java.util.*;

/**
 * @Auther: bai
 * @Date: 2018/11/26 11:10
 * @Description:
 *
 *                  任务进度：爬虫部分基本完成√    存储部分基本完成√     url去重×
 *                           中文分词完成√
 *                           lucene部分完成索引与提取demo√       增量索引×
 *                           前后端×       并发细节×       项目整体架构×         项目细节注释×
 *
 *                  目前暂定增量索引解决办法：1.数据库表中添加 flag 字段 以 0/1 衡量是否被索引。定时给未索引元组添加索引
 *                                          2.copy&paste
 *                  entity： Message[id(int), url(String), title(String), content(text), flag(int)]
 *                  lucenetest.Indexer IndexSearcher
 *                  crawler.SpiderPipeLine  crawler.SpiderProcesser
 *                  HibernateFactory    entity.MessageManager
 *                  IKAnalyzer
 *                  SearchController
 *
 *                  此项目暂时用到的包有 crawler entity utils
 *                  crawler包用于爬虫爬取部分
 *                  entity为实体包和实体与数据库交互的manager
 *                  utils为hibernate配置
 */
public class SpiderProcesser implements PageProcessor {

    // 设为 set 是为了避免抓取重复的 url
    private static Set<String> pageSet = new HashSet<String>();

    private Site site = Site
            .me()
            .setDomain("http://www.163.com")
            .setSleepTime(30)
            .setUserAgent(
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31");

    public void process(Page page) {

        String currentUrl = page.getUrl().toString();

        if(page.getHtml().getDocument().title() == "" || pageSet.contains(currentUrl) || pageSet.contains(currentUrl + "/")
                || pageSet.contains(currentUrl.substring(0, currentUrl.length()-1))) {
            page.setSkip(true);
        }
        pageSet.add(currentUrl);
        page.putField("url", page.getUrl());
        page.putField("title", page.getHtml().getDocument().title() );
        page.putField("content", page.getHtml().getDocument().text());
        page.addTargetRequests(page.getHtml().links().regex("[a-zA-z]+://[^\\s]*").all());
    }

    public Site getSite() {
        return site;
    }

    public static String getCurrentUrl() {
        MessageManager messageManager = new MessageManager();
        return messageManager.getRecentUrl();
    }

    public static void main(String[] args) {
        String currentUrl = "";
        if ("".equals(getCurrentUrl())) {
            currentUrl = "http://www.163.com";
        } else {
            currentUrl = getCurrentUrl();
        }
        Spider.create(new SpiderProcesser()).addUrl(currentUrl).addPipeline(new SpiderPipeLine()).thread(5)
                .run();

    }
}