package lucenetest;

import entity.Message;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.File;
import java.nio.file.Paths;

/**
 * @Auther: bai
 * @Date: 2018/11/30 12:55
 * @Description:
 */
public class Indexer {

    // 索引地址
    private static final String INDEX_DIR = "d:\\LucenceIndex\\SEDataBaseIndex";

    private static File file = new File(INDEX_DIR);

    static volatile IndexWriter indexWriter;

    public static synchronized void excute(Message ariticle) throws Exception{

        Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));

        Analyzer analyzer = new StandardAnalyzer();

        IndexWriterConfig config = new IndexWriterConfig(analyzer);

        config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
        indexWriter = new IndexWriter(directory, config);

//        indexWriter.deleteAll();//清除以前的index

        Document document = new Document();

        document.add(new StringField("url", ariticle.getUrl(), Field.Store.NO));
        document.add(new TextField("title", ariticle.getTitle(), Field.Store.YES));
        document.add(new TextField("text", ariticle.getText(), Field.Store.YES));
        document.add(new StringField("date", ariticle.getDate().toString(), Field.Store.NO));

        indexWriter.addDocument(document);
        System.out.println("addover---------------------------------------------------------------------------------------");

        indexWriter.close();
    }
}
