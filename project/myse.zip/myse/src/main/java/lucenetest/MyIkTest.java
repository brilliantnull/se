package lucenetest;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.wltea.analyzer.lucene.IKAnalyzer;

import java.io.StringReader;
import java.util.*;

/**
 * @Auther: bai
 * @Date: 2018/11/29 16:48
 * @Description:
 */

//            for (int k = 0; k < list.size(); k++) {
//
//                Map.Entry<String, Integer> it = list.get(k);
//
//                String word = it.getKey().toString();
//
//                System.out.println(word + "[" + it.getValue() + "]");
//
//            }

public class MyIkTest {

    private static List<Map.Entry<String, Integer>> list ;

    public static String str = "中国人民银行我是中国人";

//    public static void main(String[] args) {
//
//        lucenetest.MyIkTest lucenetest = new lucenetest.MyIkTest();
//
//        list = lucenetest.wordCount("", str);
//
//        for (int k = 0; k < list.size(); k++) {
//
//                Map.Entry<String, Integer> it = list.get(k);
//
//                String word = it.getKey().toString();
//
//                System.out.print(word + "[" + it.getValue() + "]  " );
//
//            }
//    }

    public List<Map.Entry<String, Integer>> wordCount(String arg, String content) {

        Analyzer analyzer = new IKAnalyzer(false); // IK实现分词  true:用最大词长分词  false:最细粒度切分

        StringReader reader = null;

        TokenStream ts = null;
        try {

            reader = new StringReader(content);

            ts = analyzer.tokenStream(arg, reader);

            CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);

            ts.reset();

            Map<String, Integer> map = new HashMap<String, Integer>(); //统计

            while (ts.incrementToken()) {

                String str = term.toString();

                Object o = map.get(str);

                if (o == null) {
                    map.put(str, new Integer(1));

                } else {

                    Integer i = new Integer(((Integer) o).intValue() + 1);

                    map.put(str, i);

                }

            }

            List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(map.entrySet());

            Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {

                public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {

                    return (o2.getValue() - o1.getValue());

                }
            });

            return list;

//            for (int k = 0; k < list.size(); k++) {
//
//                Map.Entry<String, Integer> it = list.get(k);
//
//                String word = it.getKey().toString();
//
//                System.out.println(word + "[" + it.getValue() + "]");
//
//            }

        } catch (Exception e) {

        } finally {

            if (reader != null) {

                reader.close();

            }

            if (analyzer != null) {

                analyzer.close();

            }

        }
        return null;
    }


}

