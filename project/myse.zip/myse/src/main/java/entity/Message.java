package entity;

import lombok.Data;
import org.hibernate.annotations.Entity;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Index;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.io.Serializable;
import java.util.Date;

import static org.hibernate.annotations.Index.*;
import static org.hibernate.search.annotations.Index.YES;
import static org.hibernate.search.annotations.Store.NO;


/**
 * @Auther: bai
 * @Date: 2018/11/29 11:28
 * @Description:
 */

@Data
@Entity
@Indexed
@Table(name = "message", uniqueConstraints = {@UniqueConstraint(columnNames = {"url"})})
public class Message implements Serializable {

    @Id
    @GenericGenerator(strategy = "identity", name = "id")
    private Integer id;

    @Column(name = "url", length = 191, nullable = false, unique = true)
    private String url;

    @Field(index = YES, analyze = Analyze.YES, store = NO)
    private String title;

    private Date date;

    @Field(index = YES, analyze = Analyze.YES, store = NO)
    private String text;

    private Integer flag = 0;
}
