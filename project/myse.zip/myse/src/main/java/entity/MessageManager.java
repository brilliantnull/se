package entity;

import entity.*;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import utils.HibernateUtil;

/**
 * @Auther: bai
 * @Date: 2018/11/29 17:31
 * @Description:
 */
public class MessageManager {

    public static void save(Message message) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.save(message);
        } catch (Exception ex) {
            session.getTransaction().rollback();
        }
        session.getTransaction().commit();
    }

    public static void delete(Message message) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();

        session.beginTransaction();

        session.delete(message);

        session.getTransaction().commit();
    }

    public static String getRecentUrl() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();

        session.beginTransaction();

        Query query = session.createQuery("select m.url from Message as m ORDER BY id DESC")
                                .setMaxResults(1);

        String recentUrl = query.list().get(0).toString();

        session.getTransaction().commit();

        return recentUrl;
    }
}
